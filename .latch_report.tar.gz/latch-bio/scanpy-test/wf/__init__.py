"""
Testing Scanpy on Latch
"""

from pathlib import Path

from latch import small_task, workflow
from latch.types import LatchFile
import scanpy as sc

# Read in scanpy adata
@small_task
def load_anndata_task(adata_path: LatchFile) -> LatchFile:

    # A reference to our output.
    adata_file = Path("adata_output.h5ad").resolve()
    adata = sc.read_h5ad(adata_path.local_path)
    print(adata.shape)
    adata.write('adata_output.h5ad')
    adata1 = sc.read_h5ad('adata_output.h5ad')
    print(adata1.shape)


    return LatchFile(str(adata_file), "latch:///adata_output.h5ad")


@workflow
def test(adata_path: LatchFile) -> LatchFile:
    """Description...

    Scanpy Test
    ----

    Write some documentation about your workflow in
    markdown here:

    > Regular markdown constructs work as expected.

    # Heading

    * testing scanpy content
    * content2

    __metadata__:
        display_name: Read in AnnData test
        author:
            name:
            email:
            github:
        repository:
        license:
            id: MIT

    Args:

        adata_path:
          Path to h5ad file of scanpy anndata object.

          __metadata__:
            display_name: adata_path

    """
    return load_anndata_task(adata_path=adata_path)


if __name__ == "__main__":
    test(adata_path=LatchFile("/mnt/c/Users/maxru/Code/latch-bio/scanpy-test/data/pbmc3k.h5ad"))